package com.ovs.admin;


import com.ovs.dao.CandidateDao;
import com.ovs.entities.Candidate;
import java.sql.SQLException;
import java.util.List;

public class AdminMenu {

    // Method to view candidates and their vote counts
    public static void viewVoteCounts() {
        try (CandidateDao dao = new CandidateDao()) {
            List<Candidate> candidateList = dao.getAllCandidates();
            System.out.println("****** Candidate List with Vote Counts ******");
            for (Candidate candidate : candidateList) {
                System.out.println("Candidate ID: " + candidate.getId() +
                                   ", Name: " + candidate.getName() +
                                   ", Symbol: " + candidate.getSymbol() +
                                   ", Votes: " + candidate.getVoteCount());
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving the candidate list with vote counts.");
            e.printStackTrace();
        }
    }
}

