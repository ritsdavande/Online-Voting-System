package com.ovs.admin;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.ovs.dao.CandidateDao;
import com.ovs.entities.Candidate;

public class Admin {

    public void showAdminMenu() {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n=== Admin Menu ===");
            System.out.println("0. Exit");
            System.out.println("1. View Voting List");
            System.out.println("2. View Voting Results");
            System.out.print("Enter your choice: ");

            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    viewVotingList();  // View candidate list with symbols only
                    break;
                case 2:
                    viewVotingResults();  // View voting results (vote count)
                    break;
                case 0:
                    System.out.println("Exiting Admin Menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);

        scanner.close();
    }

    // Method to view the list of candidates (without vote count)
    private void viewVotingList() {
        System.out.println("\n=== Voting List ===");
        try (CandidateDao dao = new CandidateDao()) {
            List<Candidate> candidates = dao.getAllCandidates();  // Get candidates from DB
            if (candidates.isEmpty()) {
                System.out.println("No candidates available.");
            } else {
                // Display only candidate name and symbol
                for (Candidate candidate : candidates) {
                    System.out.println("Candidate ID: " + candidate.getId() + 
                                       ", Name: " + candidate.getName() + 
                                       ", Symbol: " + candidate.getSymbol());  // No vote count here
                }
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving voting list.");
            e.printStackTrace();
        }
    }

    // Method to view voting results (vote count) 
    private void viewVotingResults() {
        System.out.println("\n=== Voting Results ===");
        try (CandidateDao dao = new CandidateDao()) {
            List<Candidate> candidates = dao.getAllCandidates();  // Get candidates from DB
            if (candidates.isEmpty()) {
                System.out.println("No candidates available.");
            } else {
                int totalVoters = dao.getTotalVoters();  // Get total number of voters
                Candidate winner = dao.getWinner();  // Get the winner (candidate with max votes)

                // Display candidate results with votes
                for (Candidate candidate : candidates) {
                    System.out.println("Candidate ID: " + candidate.getId() + 
                                       ", Name: " + candidate.getName() + 
                                       ", Votes: " + candidate.getVoteCount());  // Show vote count here
                }

                // Display total voters and the winner
                System.out.println("\nTotal Voters: " + totalVoters);
                if (winner != null) {
                    System.out.println("Winner: " + winner.getName() + " with " + winner.getVoteCount() + " votes.");
                } else {
                    System.out.println("No winner yet.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving voting results.");
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Admin admin = new Admin();
        admin.showAdminMenu();
    }
}
