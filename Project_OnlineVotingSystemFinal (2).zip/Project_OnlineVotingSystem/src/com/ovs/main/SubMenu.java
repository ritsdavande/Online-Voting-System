package com.ovs.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.ovs.dao.CandidateDao;
import com.ovs.entities.User;
import com.ovs.entities.Candidate;

public class SubMenu {

    // Display the SubMenu
    public static void subMenu(User user, Scanner sc) {
        int choice;
        do {
            System.out.println("****** Online Voting System Menu ******");
            System.out.println("0. Logout");
            System.out.println("1. View Candidate List");
            System.out.println("2. Cast Vote");
            System.out.println("***************************************");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 0:
                    System.out.println("Logging out...");
                    break;
                case 1:
                    viewCandidateList();
                    break;
                case 2:
                    castVote(user, sc);
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
                    break;
            }
        } while (choice != 0);
    }

    // Display the list of candidates
    public static void viewCandidateList() {
        try (CandidateDao dao = new CandidateDao()) {
            List<Candidate> candidateList = dao.getAllCandidates();
            System.out.println("****** Candidate List ******");
            for (Candidate candidate : candidateList) {
                System.out.println("Candidate ID: " + candidate.getId() +
                                   ", Name: " + candidate.getName() +
                                   ", Symbol: " + candidate.getSymbol());
                                  
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving the candidate list.");
            e.printStackTrace();
        }
    }

    // Allow the user to cast their vote
    public static void castVote(User user, Scanner sc) {
        System.out.print("Enter the ID of the candidate you want to vote for: ");
        int candidateId = sc.nextInt();

        // Ensure the user has logged in and we have their details
        if (user == null) {
            System.out.println("You need to log in first before casting a vote.");
            return;
        }

        try (CandidateDao candidateDao = new CandidateDao()) {
            // Check if the candidate ID exists
            List<Candidate> candidates = candidateDao.getAllCandidates();
            boolean validCandidate = candidates.stream().anyMatch(candidate -> candidate.getId() == candidateId);

            if (!validCandidate) {
                System.out.println("Invalid candidate ID. Please try again.");
                return;
            }

            // Check if the user has already voted
            if (candidateDao.hasVoted(user.getEmail())) {
                System.out.println("You have already voted! You can only vote once.");
                return;
            }

            // Record the vote in the database
            boolean success = candidateDao.castVote(user.getEmail(), candidateId); // Using email to uniquely identify the user
            if (success) {
                System.out.println("Your vote has been successfully cast. Thank you!");
            } else {
                System.out.println("Failed to cast your vote. Please try again.");
            }
        } catch (SQLException e) {
            System.out.println("An error occurred while casting your vote.");
            e.printStackTrace();
        }
    }
}
