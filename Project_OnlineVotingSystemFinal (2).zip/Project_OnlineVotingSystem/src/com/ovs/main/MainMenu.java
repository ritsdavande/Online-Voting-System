package com.ovs.main;


import java.sql.SQLException;
import java.util.Scanner;

import com.ovs.dao.*;
import com.ovs.entities.*;
public class MainMenu {

		public static int menu(Scanner sc) {
			System.out.println("******Welcome to Online Voting System Platform*******");
			System.out.println("0. EXIT");
			System.out.println("1. Login");
			System.out.println("2. Register");
			System.out.println("***********************************");
			System.out.println("Enter your choice - ");
			int choice = sc.nextInt();
			return choice;

		}

		
		public static void registerUser(Scanner sc) {
		    User user = new User(); // Create a User object
		    user.acceptUser(sc); // Accept user details

		    try (UserDao userdao = new UserDao()) { // Use a different name for the UserDao object
		        userdao.insertUser(user); // Pass the User object to the insertUser method
		    } catch (SQLException e) {
		        e.printStackTrace(); // Handle SQL exceptions
		    }
		}

		public static User loginUser(Scanner sc) {
		    int attempts = 0; // Counter for login attempts
		    final int MAX_ATTEMPTS = 3; // Maximum allowed attempts

		    while (attempts < MAX_ATTEMPTS) { // Loop for up to MAX_ATTEMPTS
		        System.out.print("Enter email id - ");
		        String email = sc.next();
		        System.out.print("Enter password - ");
		        String password = sc.next();

		        try (UserDao userDao = new UserDao()) {
		            User user = userDao.getUser(email, password);
		            if (user != null) { // Successful login
		                System.out.println("Login successful... :)");
		                return user;
		            } else {
		                attempts++;
		                System.out.println("Invalid email or password.");
		                if (attempts < MAX_ATTEMPTS) {
		                    System.out.println("Attempts remaining: " + (MAX_ATTEMPTS - attempts));
		                } else {
		                    System.out.println("You have exceeded the maximum login attempts.");
		                    System.out.println("Please use the 'Forget Password' option.");
		                }
		            }
		        } catch (SQLException e) {
		            e.printStackTrace();
		            return null;
		        }
		    }
		    return null; // Return null after exceeding attempts
		}
		
		public static void forgetPassword(Scanner sc) {
		    System.out.println("Forget Password process initiated.");
		    System.out.println("Please contact support or use the reset password link sent to your email.");
		}




		public static void main(String[] args) {
			int choice = 0;
			Scanner sc = new Scanner(System.in);
			while ((choice = menu(sc)) != 0) {
				switch (choice) {
				case 1:
				
				    User user = loginUser(sc);
				    if (user != null) {
				        SubMenu.subMenu(user, sc); // Proceed if login is successful
				    } else {
				        System.out.println("Returning to the main menu...");
				        forgetPassword(sc); // Call Forget Password after exceeding attempts
				    }
				    break;

				case 2:
					registerUser(sc);
					break;

				default:
					System.out.println("Wrong choice...");
					break;
				}
			}

		}

	}


