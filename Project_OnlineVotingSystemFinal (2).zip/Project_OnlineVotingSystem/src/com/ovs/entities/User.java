package com.ovs.entities;

import java.util.Scanner;

public class User {
	String name;
	String email;
     String mobile ;
      String college_name ;
	String username;
	String password ;
	private boolean hasVoted;
	

//	public class User {
//	    private String email;
//	    private String password;
//	    private boolean hasVoted; // New attribute
//
//	    // Getters and setters
//	    public boolean isHasVoted() {
//	        return hasVoted;
//	    }
//
//	    public void setHasVoted(boolean hasVoted) {
//	        this.hasVoted = hasVoted;
//	    }
//
//	    // Other existing fields and methods
//	}

	public User() {
		
	}
	public User(String name, String email, String mobile, String college_name, String username, String password) {
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.college_name = college_name;
		this.username = username;
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getCollege_name() {
		return college_name;
	}
	public void setCollege_name(String college_name) {
		this.college_name = college_name;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public boolean isHasVoted() {
        return hasVoted;
    }

    public void setHasVoted(boolean hasVoted) {
        this.hasVoted = hasVoted;
    }
	@Override
	public String toString() {
		return "user [name=" + name + ", email=" + email + ", mobile=" + mobile + ", college_name=" + college_name
				+ ", username=" + username + ", password=" + password + "]";
	}
	public void acceptUser(Scanner sc) {
		// TODO Auto-generated method stub
		System.out.print("Enter the Username(as your PRN) - ");
		name = sc.next();
		System.out.print("Enter the email - ");
		email = sc.next();
		System.out.print("Enter the password - ");
		password = sc.next();
		System.out.print("Enter the mobile no. - ");
		mobile = sc.next();
	}
	
	
}


