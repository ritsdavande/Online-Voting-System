package com.ovs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ovs.entities.Candidate;
import com.ovs.utils.DButil;

public class CandidateDao implements AutoCloseable {
    private Connection connection;

    public CandidateDao() throws SQLException {
        connection = DButil.getConnection();
    }

    // Method to add a candidate
    public boolean addCandidate(Candidate candidate) throws SQLException {
        String sql = "INSERT INTO votinglist (candidate_name, symbol) VALUES (?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, candidate.getName());
            stmt.setString(2, candidate.getSymbol());
            return stmt.executeUpdate() > 0; // Returns true if insertion is successful
        }
    }

    // Method to cast a vote
    public boolean castVote(String userEmail, int candidateId) throws SQLException {
        if (hasVoted(userEmail)) {
            System.out.println("You have already voted! You can vote only once.");
            return false;
        }

        // Insert the vote into the votes table
        String sql = "INSERT INTO votes (user_email, candidate_id) VALUES (?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, userEmail);
            stmt.setInt(2, candidateId);
            boolean voteInserted = stmt.executeUpdate() > 0;
            
            // If the vote was inserted successfully, update the vote count
            if (voteInserted) {
                updateVoteCount(candidateId); // Increment the vote count for the candidate
            }
            return voteInserted;
        }
    }

    // Method to check if a user has already voted
    public boolean hasVoted(String userEmail) throws SQLException {
        String sql = "SELECT COUNT(*) FROM votes WHERE user_email = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, userEmail);
            ResultSet rs = stmt.executeQuery();
            return rs.next() && rs.getInt(1) > 0;
        }
    }

    // Method to get all candidates with their current vote counts
    public List<Candidate> getAllCandidates() throws SQLException {
        String sql = "SELECT * FROM votinglist";
        List<Candidate> candidates = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Candidate candidate = new Candidate();
                candidate.setId(rs.getInt("vid"));
                candidate.setName(rs.getString("candidate_name"));
                candidate.setSymbol(rs.getString("symbol"));
                candidate.setVoteCount(getVoteCount(candidate.getId())); // Get the current vote count
                candidates.add(candidate);
            }
        }
        return candidates;
    }

    // Method to get a candidate by ID
    public Candidate getCandidateById(int id) throws SQLException {
        String sql = "SELECT * FROM votinglist WHERE vid = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Candidate candidate = new Candidate();
                candidate.setId(rs.getInt("vid"));
                candidate.setName(rs.getString("candidate_name"));
                candidate.setSymbol(rs.getString("symbol"));
                candidate.setVoteCount(getVoteCount(id)); // Get the current vote count
                return candidate;
            }
        }
        return null;
    }

    // Method to get the current vote count for a candidate
    private int getVoteCount(int candidateId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM votes WHERE candidate_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, candidateId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0; // Return 0 if no votes found
    }

    // Method to update the vote count in the votinglist table (increment vote count)
    private void updateVoteCount(int candidateId) throws SQLException {
        String sql = "UPDATE votinglist SET vote_count = vote_count + 1 WHERE vid = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, candidateId);
            stmt.executeUpdate();
        }
    }
 // Method to get the total number of voters who have cast their votes
    public int getTotalVoters() throws SQLException {
        String sql = "SELECT COUNT(DISTINCT user_email) FROM votes";  // Counting distinct voters
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);  // Return the total number of voters
            }
        }
        return 0;  // Return 0 if no voters
    }
 // Method to get the candidate with the maximum votes
    public Candidate getWinner() throws SQLException {
        String sql = "SELECT v.vid, v.candidate_name, v.symbol, COUNT(*) AS vote_count " +
                     "FROM votes AS t " +
                     "JOIN votinglist AS v ON t.candidate_id = v.vid " +
                     "GROUP BY t.candidate_id " +
                     "ORDER BY vote_count DESC LIMIT 1";  // Get the candidate with the highest votes

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Candidate winner = new Candidate();
                winner.setId(rs.getInt("vid"));
                winner.setName(rs.getString("candidate_name"));
                winner.setSymbol(rs.getString("symbol"));
                winner.setVoteCount(rs.getInt("vote_count"));
                return winner;
            }
        }
        return null;  // Return null if no winner found
    }


    @Override
    public void close() throws SQLException {
        if (connection != null) {
            connection.close();
        }
    }
}
