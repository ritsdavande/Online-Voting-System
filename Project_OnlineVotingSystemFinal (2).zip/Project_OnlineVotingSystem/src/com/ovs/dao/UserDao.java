package com.ovs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.ovs.entities.User;
import com.ovs.utils.DButil;

public class UserDao implements AutoCloseable {
    private final Connection connection;

    public UserDao() throws SQLException {
        connection = DButil.getConnection();
    }

    /**
     * Inserts a new user into the database.
     * @param user the User object containing user details.
     * @throws SQLException if a database error occurs.
     */
    public void insertUser(User user) throws SQLException {
        String sql = "INSERT INTO user (name, email, password, mobile) VALUES (?, ?, ?, ?)";
        try (PreparedStatement insertStmt = connection.prepareStatement(sql)) {
            insertStmt.setString(1, user.getName());
            insertStmt.setString(2, user.getEmail());
            insertStmt.setString(3, user.getPassword());
            insertStmt.setString(4, user.getMobile());
            insertStmt.executeUpdate();
        }
    }

    /**
     * Retrieves a user from the database based on their email and password.
     * @param email the user's email.
     * @param password the user's password.
     * @return a User object if found; otherwise, null.
     * @throws SQLException if a database error occurs.
     */
    public User getUser(String email, String password) throws SQLException {
        String sql = "SELECT * FROM user WHERE email = ? AND password = ?";
        try (PreparedStatement selectStmt = connection.prepareStatement(sql)) {
            selectStmt.setString(1, email);
            selectStmt.setString(2, password);
            try (ResultSet rs = selectStmt.executeQuery()) {
                if (rs.next()) {
                    return extractUserFromResultSet(rs);
                }
            }
        }
        return null;
    }

    /**
     * Extracts user data from a ResultSet.
     * @param rs the ResultSet containing user data.
     * @return a User object populated with the data from the ResultSet.
     * @throws SQLException if a database error occurs.
     */
    private User extractUserFromResultSet(ResultSet rs) throws SQLException {
        User user = new User();
        user.setName(rs.getString("name"));
        user.setEmail(rs.getString("email"));
        user.setPassword(rs.getString("password"));
        user.setMobile(rs.getString("mobile"));
        return user;
    }

    @Override
    public void close() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }
}
