package com.ovs.tester;

public class VotingListTest {

}
