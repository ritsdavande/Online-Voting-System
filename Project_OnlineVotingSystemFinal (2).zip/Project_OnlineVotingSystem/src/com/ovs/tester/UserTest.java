package com.ovs.tester;
import java.sql.SQLException;
import java.util.Scanner;

import com.ovs.dao.UserDao;
import com.ovs.entities.*;
public class UserTest {

public static void main(String[] args) throws Exception {
			Scanner sc = new Scanner(System.in);
			User user = new User();
			user.acceptUser(sc);
			try (UserDao userdao = new UserDao()) {
				userdao.insertUser(user);
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}

	}



